// src/modules/Authentication/LoginScreen.tsx
import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, TouchableWithoutFeedback,
  Keyboard, Alert, Image, ActivityIndicator, Animated, Easing, ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import type { RootStackParamList } from '../../../App';
import { supabase } from '../../utils/supabase';
import { registerPushToken } from '../../services/pushService';
import { useTheme, ThemeColors } from '../../utils/themeContext';
import { resolveHomeRoute } from '../../utils/resolveHomeRoute';

WebBrowser.maybeCompleteAuthSession();

const ORANGE = '#F27024';
const COOLDOWN_SECONDS = 60;

export default function LoginScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const insets = useSafeAreaInsets();
  const { colors, isDark, toggleDark } = useTheme();
  const styles = useMemo(() => makeStyles(colors, isDark), [colors, isDark]);

  // 'login' | '2fa'
  const [phase, setPhase] = useState<'login' | '2fa'>('login');

  // Login State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [focusedInput, setFocusedInput] = useState<string | null>(null);
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // 2FA State
  const [otpCode, setOtpCode] = useState('');
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [sentTo, setSentTo] = useState('');

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1, duration: 500,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();

    const glow = Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue: 1, duration: 2600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(glowAnim, { toValue: 0, duration: 2600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    glow.start();
    return () => glow.stop();
  }, [fadeAnim, glowAnim]);

  // Re-trigger fade animation on phase change
  useEffect(() => {
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1, duration: 500,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [phase, fadeAnim]);

  // Cooldown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return 'Email is required';
    if (!emailRegex.test(email)) return 'Please enter a valid email address';
    return '';
  };

  const validatePassword = (password: string) => {
    if (!password) return 'Password is required';
    if (password.length < 8) return 'Password must be at least 8 characters';
    return '';
  };

  const getFriendlyErrorMessage = (error: any) => {
    const message = error?.message || '';
    if (message.includes('Invalid login credentials')) return 'Invalid email or password. Please try again.';
    if (message.includes('Email not confirmed')) return 'Please verify your email address before logging in.';
    if (message.includes('Too many requests')) return 'Too many login attempts. Please try again later.';
    if (message.includes('network')) return 'Network error. Please check your internet connection.';
    return 'Something went wrong. Please try again.';
  };

  // Checks if the user is active in public.users; signs out and alerts if deactivated
  const assertAccountActive = async (authId: string, emailFallback?: string): Promise<boolean> => {
    let { data: userRow } = await supabase
      .from('users')
      .select('user_id, is_active')
      .eq('auth_id', authId)
      .maybeSingle();

    if (!userRow && emailFallback) {
      const { data: byEmail } = await supabase
        .from('users')
        .select('user_id, is_active')
        .eq('email', emailFallback.trim().toLowerCase())
        .maybeSingle();
      userRow = byEmail;
    }

    if (userRow && userRow.is_active === false) {
      await supabase.auth.signOut();
      Alert.alert(
        'Account Deactivated',
        'Your account has been deactivated by an administrator. Please contact Pack-N-Ship Support for assistance.'
      );
      return false;
    }

    return true;
  };

  const handleLogin = async () => {
    const emailValidation = validateEmail(email);
    const passwordValidation = validatePassword(password);
    if (emailValidation) { setEmailError(emailValidation); return; }
    if (passwordValidation) { setPasswordError(passwordValidation); return; }

    setLoading(true);
    try {
      const { data: signInData, error } = await supabase.auth.signInWithPassword({ 
        email: email.trim(), 
        password 
      });

      if (error) throw error;

      // Block login immediately if account is deactivated in public.users
      const isActive = await assertAccountActive(signInData.user.id, email.trim());
      if (!isActive) return;

      // Check if 2FA is enabled
      if (signInData?.user?.user_metadata?.two_factor_enabled) {
        // Send 6-digit OTP to email
        const { error: otpError } = await supabase.auth.signInWithOtp({
          email: email.trim(),
          options: { shouldCreateUser: false },
        });
        if (otpError) throw otpError;

        // Log them out temporarily to force OTP verification
        await supabase.auth.signOut();
        
        // Show OTP screen
        setSentTo(email.trim().toLowerCase());
        setPhase('2fa');
        setCooldown(COOLDOWN_SECONDS);
        return;
      }

      // If no 2FA, route straight to dashboard
      await routeToDashboard(signInData.user.id);

    } catch (error: any) {
      Alert.alert('Login Failed', getFriendlyErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otpCode || otpCode.length < 6) {
      Alert.alert('Invalid Code', 'Please enter the 6-digit code sent to your email.');
      return;
    }

    setVerifyingOtp(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email: sentTo,
        token: otpCode.trim(),
        type: 'email',
      });

      if (error) throw error;

      if (data?.user) {
        const isActive = await assertAccountActive(data.user.id, sentTo);
        if (!isActive) {
          setPhase('login');
          setOtpCode('');
          return;
        }
        await routeToDashboard(data.user.id);
      }

    } catch (err: any) {
      Alert.alert('Verification Failed', err.message || 'The code is invalid or has expired.');
    } finally {
      setVerifyingOtp(false);
    }
  };

  const handleResendOtp = async () => {
    if (cooldown > 0) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: sentTo,
        options: { shouldCreateUser: false },
      });
      if (error) throw error;
      setCooldown(COOLDOWN_SECONDS);
      Alert.alert('Code Sent', 'A new 6-digit code has been sent to your email.');
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Could not resend the code.');
    } finally {
      setLoading(false);
    }
  };

  const routeToDashboard = async (authId: string) => {
    const isActive = await assertAccountActive(authId);
    if (!isActive) return;

    const route = await resolveHomeRoute(authId);
    (async () => {
      try {
        const { data: userRow } = await supabase.from('users').select('user_id').eq('auth_id', authId).maybeSingle();
        if (userRow?.user_id) await registerPushToken(userRow.user_id);
      } catch (e) {
        console.warn('[push] registration skipped:', e);
      }
    })();
    navigation.reset({ index: 0, routes: [{ name: route }] });
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const redirectTo = Linking.createURL('auth/callback');

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo,
          skipBrowserRedirect: true,
        },
      });

      if (error) throw error;
      if (!data?.url) throw new Error('Could not start Google Sign-In.');

      const result = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);
      if (result.type !== 'success' || !result.url) {
        return;
      }

      // Extract either PKCE ?code= or implicit #access_token=...&refresh_token=...
      const returnedUrl = result.url;
      const parsed = Linking.parse(returnedUrl);
      const queryParams = (parsed.queryParams ?? {}) as Record<string, string | undefined>;

      let access_token = queryParams.access_token;
      let refresh_token = queryParams.refresh_token;
      const code = queryParams.code;

      if (!access_token && returnedUrl.includes('#')) {
        const hash = returnedUrl.split('#')[1];
        const hashParams = new URLSearchParams(hash);
        access_token = hashParams.get('access_token') || undefined;
        refresh_token = hashParams.get('refresh_token') || undefined;
      }

      let authUser: any = null;

      if (access_token && refresh_token) {
        const { data: sessionData, error: sessionErr } = await supabase.auth.setSession({
          access_token,
          refresh_token,
        });
        if (sessionErr) throw sessionErr;
        authUser = sessionData?.user;
      } else if (code) {
        const { data: sessionData, error: codeErr } = await supabase.auth.exchangeCodeForSession(code);
        if (codeErr) throw codeErr;
        authUser = sessionData?.user;
      } else {
        throw new Error('Google sign-in did not return a valid session token.');
      }

      if (!authUser) {
        const { data: userResp } = await supabase.auth.getUser();
        authUser = userResp?.user;
      }
      if (!authUser) throw new Error('Could not retrieve authenticated user.');

      // Ensure user exists in public.users (trg_users_default_role assigns Sender role automatically)
      const { data: existingUser } = await supabase
        .from('users')
        .select('user_id, is_active')
        .eq('auth_id', authUser.id)
        .maybeSingle();

      if (existingUser && existingUser.is_active === false) {
        await supabase.auth.signOut();
        Alert.alert(
          'Account Deactivated',
          'Your account has been deactivated by an administrator. Please contact Pack-N-Ship Support for assistance.'
        );
        return;
      }

      if (!existingUser) {
        const meta = authUser.user_metadata || {};
        const fullName = String(meta.full_name || meta.name || '').trim();
        const nameParts = fullName ? fullName.split(/\s+/) : [];
        const firstName = meta.given_name || nameParts[0] || 'User';
        const lastName = meta.family_name || (nameParts.length > 1 ? nameParts.slice(1).join(' ') : '');
        const avatarUrl = meta.avatar_url || meta.picture || null;

        // Check if email already exists (e.g. previously registered via email)
        const { data: emailMatch } = await supabase
          .from('users')
          .select('user_id, is_active')
          .eq('email', authUser.email)
          .maybeSingle();

        if (emailMatch) {
          if (emailMatch.is_active === false) {
            await supabase.auth.signOut();
            Alert.alert(
              'Account Deactivated',
              'Your account has been deactivated by an administrator. Please contact Pack-N-Ship Support for assistance.'
            );
            return;
          }

          await supabase
            .from('users')
            .update({
              auth_id: authUser.id,
              ...(avatarUrl ? { profile_photo: avatarUrl } : {}),
            })
            .eq('user_id', emailMatch.user_id);
        } else {
          const { error: insertErr } = await supabase
            .from('users')
            .insert({
              auth_id: authUser.id,
              first_name: firstName,
              last_name: lastName,
              email: authUser.email || '',
              profile_photo: avatarUrl,
              is_verified: false,
              is_active: true,
            });
          if (insertErr) throw insertErr;
        }
      }

      await routeToDashboard(authUser.id);
    } catch (err: any) {
      console.error('[GoogleLogin] error:', err);
      Alert.alert('Google Sign-In Failed', err?.message || 'Could not sign in with Google.');
    } finally {
      setLoading(false);
    }
  };

  const glowScale = glowAnim.interpolate({ inputRange: [0, 1], outputRange: [1, 1.12] });
  const glowOpacity = glowAnim.interpolate({ inputRange: [0, 1], outputRange: [0.06, 0.12] });
  const fadeUpStyle = { opacity: fadeAnim, transform: [{ translateY: fadeAnim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }] };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <TouchableOpacity
        style={[styles.themeToggle, { top: insets.top + 12 }]}
        onPress={toggleDark}
        activeOpacity={0.85}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <Ionicons name={isDark ? 'sunny-outline' : 'moon-outline'} size={20} color={colors.textPrimary} />
      </TouchableOpacity>

      <View style={styles.backgroundLayer} pointerEvents="none">
        <Animated.View style={[styles.glow, styles.glowTop, { transform: [{ scale: glowScale }], opacity: glowOpacity }]} />
        <View style={[styles.glow, styles.glowBottom]} />
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardAvoid}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <ScrollView contentContainerStyle={styles.innerContainer} showsVerticalScrollIndicator={false}>
            <Animated.View style={[styles.contentWrapper, fadeUpStyle]}>
              
              {phase === '2fa' ? (
                /* --- 2FA OTP STATE --- */
                <>
                  <View style={styles.headerContainer}>
                    <View style={styles.brandRow}>
                      <Ionicons name="shield-checkmark-outline" size={36} color={ORANGE} />
                    </View>
                    <Text style={styles.header}>Two-Factor Auth</Text>
                    <Text style={styles.subHeader}>
                      We sent a 6-digit code to{'\n'}
                      <Text style={{ fontWeight: '600', color: colors.textPrimary }}>{sentTo}</Text>
                    </Text>
                  </View>

                  <View style={styles.formContainer}>
                    <View style={[
                      styles.inputWrapper, 
                      { height: 64, marginBottom: 20 },
                      focusedInput === 'otp' && styles.inputFocused
                    ]}>
                      <Ionicons name="keypad-outline" size={24} color={focusedInput === 'otp' ? ORANGE : colors.textMuted} style={styles.inputIcon} />
                      <TextInput
                        style={[styles.input, { fontSize: 24, letterSpacing: 6, fontWeight: '700' }]}
                        placeholder="000000"
                        placeholderTextColor={colors.textMuted}
                        keyboardType="number-pad"
                        maxLength={6}
                        value={otpCode}
                        onChangeText={setOtpCode}
                        onFocus={() => setFocusedInput('otp')}
                        onBlur={() => setFocusedInput(null)}
                      />
                    </View>
                  </View>

                  <TouchableOpacity
                    style={[styles.loginButton, (verifyingOtp || otpCode.length < 6) && styles.buttonDisabled]}
                    onPress={handleVerifyOtp}
                    disabled={verifyingOtp || otpCode.length < 6}
                    activeOpacity={0.8}
                  >
                    {verifyingOtp ? <ActivityIndicator color="#FFFFFF" size="small" /> : <Text style={styles.loginText}>Verify & Log In</Text>}
                  </TouchableOpacity>

                  <View style={styles.dividerContainer}>
                    <Text style={styles.dividerText}>Didn't receive it? </Text>
                    <TouchableOpacity onPress={handleResendOtp} disabled={cooldown > 0 || loading}>
                      <Text style={{ color: cooldown > 0 ? colors.textMuted : ORANGE, fontWeight: '700', fontSize: 14 }}>
                        {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend Code'}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity onPress={() => setPhase('login')} style={{ marginTop: 10, alignItems: 'center' }}>
                    <Text style={{ color: colors.textSecondary, fontSize: 13, textDecorationLine: 'underline' }}>
                      Cancel and go back
                    </Text>
                  </TouchableOpacity>
                </>
              ) : (
                /* --- STANDARD LOGIN STATE --- */
                <>
                  <View style={styles.headerContainer}>
                    <View style={styles.brandRow}>
                      <Image source={require('../../../assets/appiconfinal2.png')} style={styles.logoImage} resizeMode="contain" />
                      <Text style={styles.brandText}>
                        Pack-<Text style={styles.brandTextOrange}>N-Ship</Text>
                      </Text>
                    </View>
                    <Text style={styles.header}>Welcome Back</Text>
                    <Text style={styles.subHeader}>Log in to manage your deliveries and track packages.</Text>
                  </View>

                  <View style={styles.formContainer}>
                    <View style={[styles.inputWrapper, focusedInput === 'email' && styles.inputFocused, emailError && styles.inputError]}>
                      <Ionicons name="mail-outline" size={20} color={focusedInput === 'email' ? ORANGE : colors.textMuted} style={styles.inputIcon} />
                      <TextInput
                        style={styles.input}
                        placeholder="Email Address"
                        placeholderTextColor={colors.textMuted}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        value={email}
                        onChangeText={(t) => { setEmail(t); setEmailError(validateEmail(t)); }}
                        onFocus={() => setFocusedInput('email')}
                        onBlur={() => setFocusedInput(null)}
                        editable={!loading}
                      />
                    </View>
                    {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}

                    <View style={[styles.inputWrapper, focusedInput === 'password' && styles.inputFocused, passwordError && styles.inputError]}>
                      <Ionicons name="lock-closed-outline" size={20} color={focusedInput === 'password' ? ORANGE : colors.textMuted} style={styles.inputIcon} />
                      <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor={colors.textMuted}
                        secureTextEntry={!showPassword}
                        value={password}
                        onChangeText={(t) => { setPassword(t); setPasswordError(validatePassword(t)); }}
                        onFocus={() => setFocusedInput('password')}
                        onBlur={() => setFocusedInput(null)}
                        editable={!loading}
                      />
                      <TouchableOpacity style={styles.eyeButton} onPress={() => setShowPassword(!showPassword)} disabled={loading}>
                        <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.textSecondary} />
                      </TouchableOpacity>
                    </View>
                    {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

                    <TouchableOpacity style={styles.forgotPasswordButton} disabled={loading} onPress={() => navigation.navigate('ForgotPassword')}>
                      <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    style={[styles.loginButton, loading && styles.buttonDisabled]}
                    onPress={handleLogin}
                    disabled={loading}
                    activeOpacity={0.8}
                  >
                    {loading ? <ActivityIndicator color="#FFFFFF" size="small" /> : <Text style={styles.loginText}>Log In</Text>}
                  </TouchableOpacity>

                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or</Text>
                    <View style={styles.dividerLine} />
                  </View>

                  <TouchableOpacity style={[styles.googleButton, loading && styles.buttonDisabled]} onPress={handleGoogleLogin} disabled={loading} activeOpacity={0.8}>
                    <Image source={require('../../../assets/google.png')} style={styles.googleIcon} resizeMode="contain" />
                    <Text style={styles.googleText}>Continue With Google</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.signUpContainer} onPress={() => navigation.navigate('Register')} disabled={loading}>
                    <Text style={styles.signUpText}>Don't have an account? <Text style={styles.signUpTextBold}>Sign Up</Text></Text>
                  </TouchableOpacity>
                </>
              )}
            </Animated.View>
          </ScrollView>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const makeStyles = (c: ThemeColors, isDark: boolean) => StyleSheet.create({
  container: { flex: 1, backgroundColor: c.background },
  keyboardAvoid: { flex: 1 },
  themeToggle: { position: 'absolute', right: 20, zIndex: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: c.card, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: c.border, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: isDark ? 0.4 : 0.08, shadowRadius: 6, elevation: 3 },
  backgroundLayer: { ...StyleSheet.absoluteFill, overflow: 'hidden' },
  glow: { position: 'absolute', borderRadius: 999, backgroundColor: ORANGE },
  glowTop: { width: 360, height: 360, top: -160, right: -140 },
  glowBottom: { width: 300, height: 300, bottom: -140, left: -120, opacity: 0.05 },
  innerContainer: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 40, flexGrow: 1, justifyContent: 'center' },
  contentWrapper: { flex: 1, justifyContent: 'center' },
  headerContainer: { marginBottom: 24, alignItems: 'flex-start' },
  brandRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 12 },
  logoImage: { width: 74, height: 74 },
  brandText: { fontSize: 29, fontWeight: '800', fontStyle: 'italic', color: c.textPrimary, letterSpacing: -0.3, marginLeft: -12 },
  brandTextOrange: { color: ORANGE },
  header: { fontSize: 28, fontWeight: '700', color: c.textPrimary, marginBottom: 6, letterSpacing: -0.5 },
  subHeader: { fontSize: 15, color: c.textSecondary, fontWeight: '400', lineHeight: 22 },
  formContainer: { marginBottom: 16 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 12, marginBottom: 12, height: 52 },
  inputIcon: { paddingLeft: 16, paddingRight: 8 },
  input: { flex: 1, height: '100%', fontSize: 15, color: c.textPrimary },
  inputFocused: { backgroundColor: c.card, borderColor: ORANGE },
  inputError: { borderColor: c.error, backgroundColor: c.errorBg },
  eyeButton: { paddingHorizontal: 16, height: '100%', justifyContent: 'center' },
  errorText: { color: c.error, fontSize: 12, fontWeight: '500', marginTop: -8, marginBottom: 10, marginLeft: 4 },
  forgotPasswordButton: { alignSelf: 'flex-end', paddingVertical: 4, marginBottom: 12 },
  forgotPasswordText: { color: ORANGE, fontSize: 14, fontWeight: '600' },
  loginButton: { backgroundColor: ORANGE, height: 54, borderRadius: 12, alignItems: 'center', justifyContent: 'center', width: '100%', marginBottom: 20 },
  buttonDisabled: { opacity: 0.7 },
  loginText: { color: '#FFFFFF', fontWeight: '600', fontSize: 16 },
  dividerContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', width: '100%', marginBottom: 20 },
  dividerLine: { flex: 1, height: 1, backgroundColor: c.border },
  dividerText: { marginHorizontal: 12, color: c.textSecondary, fontWeight: '500', fontSize: 14 },
  googleButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: c.border, borderRadius: 12, height: 54, width: '100%', marginBottom: 24, backgroundColor: c.card },
  googleIcon: { width: 22, height: 22, marginRight: 10 },
  googleText: { color: c.textPrimary, fontWeight: '600', fontSize: 15 },
  signUpContainer: { width: '100%', alignItems: 'center', paddingVertical: 8 },
  signUpText: { color: c.textSecondary, fontSize: 14 },
  signUpTextBold: { color: ORANGE, fontWeight: '600' },
});